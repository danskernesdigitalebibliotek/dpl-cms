<?php

declare(strict_types=1);

namespace Drupal\test_module\Controller;

use Drupal\Core\DependencyInjection\AutowireTrait;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\State\StateInterface;

/**
 * Simple page to tell Cypress our status.
 */
class InfoPageController implements ContainerInjectionInterface {

  use AutowireTrait;

  /**
   * Constructor.
   */
  public function __construct(private StateInterface $state) {}

  /**
   * Return the page.
   *
   * @return array<string, string>
   *   A render array.
   */
  public function page(): array {
    $updb = (string) $this->state->get('test_module_last_update', 'null');

    return [
      '#markup' => 'Version: <span id="version">1.0.1</span>Updb: <span id="updb">' .
      $updb . '</span>',
      '#prefix' => '<div id="test-module-info">',
      '#suffix' => '</div>',
    ];
  }

}
